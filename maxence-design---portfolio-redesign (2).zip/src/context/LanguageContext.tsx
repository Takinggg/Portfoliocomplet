
import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'fr' | 'en';

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  toggleLang: () => void;
  t: (key: string) => string;
  resolve: (obj: any, key: string) => string;
}

const translations: Record<string, Record<Language, string>> = {
  // Navbar
  'nav.home': { fr: 'Accueil', en: 'Home' },
  'nav.services': { fr: 'Services', en: 'Services' },
  'nav.portfolio': { fr: 'Portfolio', en: 'Portfolio' },
  'nav.casestudies': { fr: 'Études de Cas', en: 'Case Studies' },
  'nav.contact': { fr: 'Contact', en: 'Contact' },
  'nav.dashboard': { fr: 'Tableau de Bord', en: 'Dashboard' },

  // Hero
  'hero.status': { fr: 'Disponible pour nouveaux projets', en: 'Available for new projects' },
  'hero.role1': { fr: 'Designer', en: 'Designer' },
  'hero.role2': { fr: 'Digital', en: 'Digital' },
  'hero.role3': { fr: '& Développeur', en: '& Developer' },
  'hero.location': { fr: 'La Milesse, France', en: 'La Milesse, France' },
  'hero.intro': { fr: 'Je conçois des', en: 'I craft' },
  'hero.intro.highlight': { fr: 'expériences digitales radicales', en: 'radical digital experiences' },
  'hero.intro.end': { fr: 'pour des marques qui refusent de se fondre dans la masse. Esthétique et performance.', en: 'for brands that refuse to blend in. Blending aesthetics with performance.' },
  'hero.scroll': { fr: '(SCROLL) POUR EXPLORER', en: '(SCROLL) TO EXPLORE' },
  'hero.est': { fr: 'EST. 2025 PORTFOLIO', en: 'EST. 2025 PORTFOLIO' },

  // Services
  'services.title': { fr: 'Expertise', en: 'Expertise' },
  'services.subtitle': { fr: 'Design, Code & Stratégie.', en: 'Design, Code & Strategy.' },
  'services.card1.title': { fr: 'Product Design', en: 'Product Design' },
  'services.card1.desc': { fr: "Je conçois des systèmes complets, des parcours utilisateurs fluides et des interfaces qui convertissent. L'esthétique au service de la fonction.", en: "I design complete systems, seamless user journeys, and interfaces that convert. Aesthetics serving function." },
  'services.card2.title': { fr: 'Creative Dev', en: 'Creative Dev' },
  'services.card2.desc': { fr: 'React, Next.js, WebGL. Du code propre pour des expériences fluides et mémorables.', en: 'React, Next.js, WebGL. Clean code for fluid and memorable experiences.' },
  'services.card3.title': { fr: 'Intégration IA', en: 'AI Integration' },
  'services.card3.desc': { fr: "Automation & LLMs. L'intelligence artificielle pour booster votre productivité.", en: "Automation & LLMs. Artificial intelligence to boost your productivity." },

  // Process
  'process.title': { fr: 'La Méthode', en: 'The Method' },
  'process.desc': { fr: '4 étapes clés pour transformer une vision complexe en une réalité digitale performante.', en: '4 key steps to transform a complex vision into a high-performance digital reality.' },
  'process.step1.title': { fr: 'Discovery', en: 'Discovery' },
  'process.step1.sub': { fr: 'Audit & Stratégie', en: 'Audit & Strategy' },
  'process.step1.desc': { fr: "Je définis avec vous les fondations. Analyse profonde de l'existant et définition des KPIs.", en: "I define the foundations with you. Deep analysis of the existing setup and KPI definition." },
  'process.step2.title': { fr: 'Design', en: 'Design' },
  'process.step2.sub': { fr: 'UI/UX & Architecture', en: 'UI/UX & Architecture' },
  'process.step2.desc': { fr: "Création de maquettes interactives et de systèmes de design scalables.", en: "Creation of interactive mockups and scalable design systems." },
  'process.step3.title': { fr: 'Development', en: 'Development' },
  'process.step3.sub': { fr: 'Code & Intégration', en: 'Code & Integration' },
  'process.step3.desc': { fr: "Développement Front-End moderne (React/Next.js). Code propre, performant et optimisé SEO.", en: "Modern Front-End development (React/Next.js). Clean, performant, and SEO-optimized code." },
  'process.step4.title': { fr: 'Delivery', en: 'Delivery' },
  'process.step4.sub': { fr: 'Scale & Growth', en: 'Scale & Growth' },
  'process.step4.desc': { fr: "Déploiement, tests E2E et formation. Je vous donne les clés pour gérer votre croissance.", en: "Deployment, E2E tests, and training. I give you the keys to manage your growth." },

  // Work
  'work.title': { fr: 'Sélection', en: 'Selected' },
  'work.subtitle': { fr: 'Projets', en: 'Works' },
  'work.view_archive': { fr: 'Voir Archives', en: 'View Archive' },
  'work.view_all': { fr: 'Voir Tous Les Projets', en: 'View All Projects' },

  // Results
  'results.growth': { fr: 'Croissance CA', en: 'Revenue Growth' },
  'results.growth.desc': { fr: 'Moyenne observée chez mes clients E-commerce après refonte.', en: 'Average observed among my E-commerce clients after redesign.' },
  'results.speed': { fr: 'Vitesse', en: 'Speed' },
  'results.speed.desc': { fr: 'Optimisation du code et du temps de chargement.', en: 'Code optimization and load time.' },
  'results.satisfaction': { fr: 'Satisfaction', en: 'Satisfaction' },
  'results.satisfaction.desc': { fr: "Je ne m'arrête pas tant que le résultat n'est pas parfait.", en: "I don't stop until the result is perfect." },

  // Ecosystem
  'ecosystem.title': { fr: 'Digital Command Center', en: 'Digital Command Center' },
  'ecosystem.subtitle': { fr: 'Une interface interactive. Cliquez sur le dashboard pour explorer les fonctionnalités.', en: 'An interactive interface. Click the dashboard to explore features.' },
  'ecosystem.deploy': { fr: 'Déployer', en: 'Deploy App' },
  'ecosystem.building': { fr: 'Chargement...', en: 'Building...' },

  // Contact
  'contact.title': { fr: 'Lancer le', en: 'Start' },
  'contact.subtitle': { fr: 'Projet', en: 'Project' },
  'contact.desc': { fr: "Prêt à construire quelque chose d'exceptionnel ? Remplissez le manifeste technique pour initialiser la séquence.", en: "Ready to build something exceptional? Fill out the technical manifest to initialize the sequence." },
  'contact.name': { fr: 'Nom complet', en: 'Full Name' },
  'contact.email': { fr: 'Adresse email', en: 'Email Address' },
  'contact.type': { fr: 'TYPE DE MISSION', en: 'MISSION TYPE' },
  'contact.message': { fr: 'Détails de la mission...', en: 'Mission details...' },
  'contact.submit': { fr: 'Initialiser', en: 'Initialize' },
  'contact.identifier': { fr: 'IDENTIFIANT', en: 'IDENTIFIER' },
  'contact.frequency': { fr: 'FREQUENCE', en: 'FREQUENCY' },
  'contact.data': { fr: 'DONNÉES', en: 'DATA' },

  // Footer
  'footer.socials': { fr: 'Réseaux', en: 'Socials' },
  'footer.sitemap': { fr: 'Plan du site', en: 'Sitemap' },
  'footer.system': { fr: 'SYSTÈME V3.0.1', en: 'SYSTEM V3.0.1' },
  'footer.legal': { fr: 'Mentions Légales', en: 'Legal' },

  // Legal
  'legal.last_updated': { fr: 'Dernière mise à jour :', en: 'Last updated:' },

  // Pages
  'page.services.title': { fr: 'Nos Offres', en: 'Our Offers' },
  'page.services.subtitle': { fr: 'Des solutions claires, sans coûts cachés, adaptées à la maturité de votre projet.', en: 'Clear solutions, no hidden costs, adapted to your project maturity.' },
  'page.services.popular': { fr: 'Recommandé', en: 'Recommended' },
  'page.services.select': { fr: 'Choisir ce pack', en: 'Select this pack' },
  'page.services.faq': { fr: 'Questions Fréquentes', en: 'Freq. Questions' },

  'page.portfolio.title': { fr: 'Archives', en: 'Visual' },
  'page.portfolio.subtitle': { fr: 'Visuelles', en: 'Archive' },
  
  'page.casestudies.title': { fr: 'Études de Cas', en: 'Case Studies' },

  'cta.ready': { fr: 'Prêt à passer au', en: 'Ready to go to the' },
  'cta.level': { fr: 'niveau supérieur ?', en: 'next level?' },
  'cta.start': { fr: 'Démarrer le projet', en: 'Start the project' },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [lang, setLang] = useState<Language>('fr');

  const toggleLang = () => {
    setLang(prev => prev === 'fr' ? 'en' : 'fr');
  };

  const t = (key: string): string => {
    return translations[key]?.[lang] || key;
  };

  // Helper to resolve objects with _en suffixes
  const resolve = (obj: any, key: string): string => {
    if (!obj) return '';
    if (lang === 'en') {
      return obj[`${key}_en`] || obj[key] || '';
    }
    return obj[key] || '';
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, toggleLang, t, resolve }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
