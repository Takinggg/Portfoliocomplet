
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Home } from './components/home/Home';
import { ServicesPage } from './components/pages/ServicesPage';
import { PortfolioPage } from './components/pages/PortfolioPage';
import { PortfolioDetailPage } from './components/pages/PortfolioDetailPage';
import { CaseStudiesPage } from './components/pages/CaseStudiesPage';
import { CaseStudyDetailPage } from './components/pages/CaseStudyDetailPage';
import { LegalPage } from './components/pages/LegalPage';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { CustomCursor } from './components/CustomCursor';
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminLayout } from './components/admin/AdminLayout';
import { DashboardOverview } from './components/admin/DashboardOverview';
import { ProjectManager } from './components/admin/ProjectManager';
import { ServiceManager } from './components/admin/ServiceManager';
import { MessageInbox } from './components/admin/MessageInbox';
import { CRMManager } from './components/admin/CRMManager';
import { FinanceManager } from './components/admin/FinanceManager';
import { CalendarManager } from './components/admin/CalendarManager';
import { LegalManager } from './components/admin/LegalManager';
import { PageView, AdminView, Project, ServicePack, Message, Client, Quote, Invoice, Appointment, Notification, LegalDoc } from './types';
import { X } from 'lucide-react';
import { LanguageProvider } from './src/context/LanguageContext';

// INITIAL DATA
const INITIAL_PROJECTS: Project[] = [
  {
    id: 1,
    title: "Velvet Finance",
    title_en: "Velvet Finance",
    client: "Velvet Bank",
    category: "Fintech",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2670&auto=format&fit=crop",
    description: "Architecture complète d'une banque mobile nouvelle génération.",
    description_en: "Complete architecture for a next-gen mobile banking app.",
    challenge: "Velvet voulait disrupter le marché bancaire avec une approche mobile-first.",
    challenge_en: "Velvet wanted to disrupt the banking market with a mobile-first approach.",
    solution: "Une architecture headless séparant la logique bancaire de l'UI pour une sécurité maximale.",
    solution_en: "A headless architecture separating banking logic from UI for maximum security.",
    tags: ["Mobile", "React Native", "Supabase"],
    link: "#",
    stats: [{label: "Users", value: "50k+"}, {label: "App Store", value: "4.9"}],
    techStack: [{name: "React Native", category: "Mobile"}, {name: "Supabase", category: "Backend"}]
  },
  {
    id: 2,
    title: "Chronos SaaS",
    title_en: "Chronos SaaS",
    client: "Chronos Tech",
    category: "SaaS",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2426&auto=format&fit=crop",
    description: "Plateforme d'analytics B2B avec visualisation complexe.",
    description_en: "B2B analytics platform with complex visualization.",
    tags: ["React", "D3.js", "Node.js"],
    link: "#",
    stats: [{label: "Data", value: "1TB/j"}, {label: "Clients", value: "120"}],
    techStack: [{name: "D3.js", category: "Viz"}, {name: "Node.js", category: "Backend"}]
  },
  {
    id: 3,
    title: "Maison Noire",
    title_en: "Black House",
    client: "LVMH Group",
    category: "E-Commerce",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=2670&auto=format&fit=crop",
    description: "Flagship digital immersif en WebGL.",
    description_en: "Immersive WebGL digital flagship.",
    tags: ["WebGL", "Shopify", "Motion"],
    link: "#",
    stats: [{label: "Conversion", value: "+45%"}, {label: "Awards", value: "Awwwards"}],
    techStack: [{name: "WebGL", category: "3D"}, {name: "Shopify", category: "CMS"}]
  }
];

const INITIAL_SERVICES: ServicePack[] = [
  {
    id: 'starter',
    title: 'Landing Pack',
    title_en: 'Landing Pack',
    price: 'À partir de 3k€',
    price_en: 'From 3k€',
    description: 'Idéal pour lancer un produit ou tester une idée rapidement.',
    description_en: 'Ideal for launching a product or testing an idea quickly.',
    features: ['Design UI/UX sur-mesure', 'Développement React/Next.js', 'Animations Motion', 'Optimisation SEO de base', 'Livraison en 2 semaines'],
    features_en: ['Custom UI/UX Design', 'React/Next.js Development', 'Motion Animations', 'Basic SEO', '2 Weeks Delivery'],
  },
  {
    id: 'pro',
    title: 'Ecosystem',
    title_en: 'Ecosystem',
    price: 'Sur Devis',
    price_en: 'Custom Quote',
    description: 'Une solution complète : Site vitrine + Dashboard/CRM + Intégrations.',
    description_en: 'A complete solution: Website + Dashboard/CRM + Integrations.',
    features: ['Architecture Full Stack', 'Backend Supabase', 'CMS Personnalisé', 'Auth & Rôles', 'Analytics avancées', 'Support 3 mois'],
    features_en: ['Full Stack Architecture', 'Supabase Backend', 'Custom CMS', 'Auth & Roles', 'Advanced Analytics', '3 Months Support'],
    popular: true,
  },
  {
    id: 'scale',
    title: 'Scale-Up',
    title_en: 'Scale-Up',
    price: 'TJM / Retainer',
    price_en: 'Daily Rate',
    description: 'Accompagnement long terme pour équipes produit.',
    description_en: 'Long term support for product teams.',
    features: ['Design System', 'Refonte UX continue', 'Audit de performance', 'Consulting Technique', 'Workshops équipe'],
    features_en: ['Design System', 'Continuous UX', 'Performance Audit', 'Tech Consulting', 'Team Workshops'],
  },
];

const INITIAL_MESSAGES: Message[] = [
    { id: 1, name: "Alice Freeman", email: "alice@tech.co", type: "Web App", message: "Hi, looking for a full redesign of our SaaS dashboard.", date: "2 hours ago", status: "new" },
    { id: 2, name: "Marc Dupont", email: "marc@agency.fr", type: "Audit", message: "Besoin d'un audit de performance sur notre site Next.js.", date: "1 day ago", status: "read" },
];

// HRIS STYLE MOCK DATA
const INITIAL_CLIENTS: Client[] = [
    { id: 101, name: "Randy Rhiel Madsen", company: "Design Team", role: "UI Designer", department: "Design", email: "randy@mail.com", status: "active", joinDate: "11 Aug 2024", totalRevenue: "€12,400" },
    { id: 102, name: "Maria Rosser", company: "Design Team", role: "UX Researcher", department: "Design", email: "maria@mail.com", status: "inactive", joinDate: "25 Jun 2024", totalRevenue: "€0" },
    { id: 103, name: "Cheyenne Bothman", company: "Dev Team", role: "iOS Developer", department: "Engineering", email: "bothman@mail.com", status: "onboarding", joinDate: "20 Feb 2025", totalRevenue: "€0" },
    { id: 104, name: "Alfredo Curtis", company: "Dev Team", role: "Android Dev", department: "Engineering", email: "alfredo@mail.com", status: "active", joinDate: "14 May 2024", totalRevenue: "€8,200" },
    { id: 105, name: "Ryan Saris Lewis", company: "Dev Team", role: "Backend Dev", department: "Engineering", email: "ryan@mail.com", status: "active", joinDate: "31 July 2024", totalRevenue: "€15,000" },
];

const INITIAL_QUOTES: Quote[] = [
    { id: "Q-2024-001", clientId: 102, clientName: "Maria Rosser", title: "Website Redesign", amount: 4500, status: "sent", date: "2024-10-01", items: [] },
    { id: "Q-2024-002", clientId: 103, clientName: "Cheyenne Bothman", title: "Mobile App MVP", amount: 12000, status: "accepted", date: "2024-10-15", items: [] },
];

const INITIAL_INVOICES: Invoice[] = [
    { id: "INV-001", clientId: 101, clientName: "Randy Rhiel Madsen", amount: 3200, status: "paid", date: "2024-09-01", dueDate: "2024-09-30" },
    { id: "INV-002", clientId: 104, clientName: "Alfredo Curtis", amount: 8200, status: "overdue", date: "2024-08-15", dueDate: "2024-09-15" },
];

const INITIAL_APPOINTMENTS: Appointment[] = [
    { id: 1, clientId: 102, clientName: "Maria Rosser", title: "Discovery Call", date: "2024-10-22T10:00:00", duration: 45, type: "discovery" },
    { id: 2, clientId: 101, clientName: "Randy Madsen", title: "Sprint Review", date: "2024-10-23T14:00:00", duration: 60, type: "review" },
];

const INITIAL_LEGAL: LegalDoc[] = [
    { 
        id: 'terms', 
        title: 'Mentions Légales & CGU', 
        title_en: 'Legal Notice & Terms of Use', 
        content: `1. IDENTITÉ DE L'ENTREPRISE
Ce site est édité par Maxence FOULON.
Statut juridique : Micro-entreprise (Auto-entrepreneur).
SIRET : 930 179 932 R.C.S
Siège social : La Milesse, France.
Email de contact : contact@maxence.design
Directeur de la publication : Maxence FOULON

2. HÉBERGEMENT
Le site est hébergé par :
Netlify Inc.
44 Montgomery Street, Suite 300,
San Francisco, California 94104, USA.

3. PROPRIÉTÉ INTELLECTUELLE
Je suis propriétaire exclusif de tous les droits de propriété intellectuelle ou détient les droits d’usage sur tous les éléments accessibles sur le site, tant sur la structure que sur les textes, images, graphismes, logo, icônes, sons, logiciels.
Toute reproduction, représentation, modification, publication, adaptation de tout ou partie des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite, sauf autorisation écrite préalable.

4. LIMITATION DE RESPONSABILITÉ
Je ne pourrai être tenu responsable des dommages directs et indirects causés au matériel de l’utilisateur, lors de l’accès au site. Le site a pour objet de fournir une information concernant l’ensemble des activités. Je m’efforce de fournir sur le site des informations aussi précises que possible.`,
        content_en: `1. COMPANY IDENTITY
This website is published by Maxence FOULON.
Legal Status: Sole Proprietorship (Micro-entreprise).
SIRET: 930 179 932 R.C.S
Headquarters: La Milesse, France.
Contact Email: contact@maxence.design
Publication Director: Maxence FOULON

2. HOSTING
The website is hosted by:
Netlify Inc.
44 Montgomery Street, Suite 300,
San Francisco, California 94104, USA.

3. INTELLECTUAL PROPERTY
I am the exclusive owner of all intellectual property rights or hold usage rights on all elements accessible on the site, both on the structure and on the texts, images, graphics, logos, icons, sounds, software.
Any reproduction, representation, modification, publication, adaptation of all or part of the elements of the site, regardless of the means or process used, is prohibited without prior written permission.

4. LIMITATION OF LIABILITY
I cannot be held liable for direct or indirect damage caused to the user's equipment when accessing the site. The purpose of the site is to provide information concerning all of the company's activities. I strive to provide as accurate information as possible on the site.`,
        lastUpdated: '2024-10-24' 
    },
    { 
        id: 'sales', 
        title: 'Conditions Générales de Vente (CGV)', 
        title_en: 'Terms of Sales (CGV)', 
        content: `1. OBJET
Les présentes CGV régissent la vente de prestations de services (design, développement web, conseil) effectuées par Maxence FOULON (le Prestataire) pour le compte de ses clients professionnels ou particuliers (le Client).

2. COMMANDES ET DEVIS
Chaque prestation fait l'objet d'un devis gratuit, valable 30 jours. La validation de la commande se fait par la signature du devis (ou validation électronique) accompagnée du versement d'un acompte de 30% à 50% selon le projet.

3. PRIX ET PAIEMENT
Les prix sont indiqués en Euros (€). TVA non applicable, art. 293 B du CGI.
Modalités de paiement : Virement bancaire.
Délais de paiement : Sauf mention contraire sur la facture, le paiement est dû à réception.
Pénalités de retard : En cas de retard de paiement, une pénalité égale à 3 fois le taux d'intérêt légal en vigueur sera exigible, ainsi qu'une indemnité forfaitaire de 40€ pour frais de recouvrement (Articles L441-6 et D441-5 du Code de Commerce).

4. RÉSERVE DE PROPRIÉTÉ
Le Prestataire conserve la propriété pleine et entière des produits et créations vendus jusqu'au parfait encaissement du prix, en principal, frais et taxes compris.
Le transfert des droits d'utilisation et de propriété intellectuelle ne s'opère qu'après le paiement INTÉGRAL de la commande par le Client.

5. OBLIGATIONS DU CLIENT
Le Client s'engage à fournir tous les éléments (textes, images, accès) nécessaires à la réalisation de la prestation dans les délais convenus. Tout retard du Client entraînera un report de la livraison.

6. TRIBUNAL COMPÉTENT
En cas de litige et à défaut d'accord amiable, le Tribunal de Commerce de Paris sera seul compétent.`,
        content_en: `1. OBJECT
These GTCS govern the sale of services (design, web development, consulting) performed by Maxence FOULON (the Provider) on behalf of its professional or private clients (the Client).

2. ORDERS AND QUOTES
Each service is subject to a free quote, valid for 30 days. Order validation is done by signing the quote (or electronic validation) accompanied by a deposit payment of 30% to 50% depending on the project.

3. PRICES AND PAYMENT
Prices are indicated in Euros (€). VAT not applicable, art. 293 B of the CGI.
Payment methods: Bank transfer.
Payment terms: Unless otherwise stated on the invoice, payment is due upon receipt.
Late penalties: In case of late payment, a penalty equal to 3 times the legal interest rate in force will be due, as well as a fixed compensation of €40 for recovery costs.

4. RETENTION OF TITLE
The Provider retains full ownership of the sold products and creations until full payment of the price, including principal, costs, and taxes.
The transfer of usage and intellectual property rights occurs only after FULL payment of the order by the Client.

5. CLIENT OBLIGATIONS
The Client agrees to provide all elements (texts, images, access) necessary for the performance of the service within the agreed deadlines. Any delay by the Client will result in a postponement of delivery.

6. COMPETENT COURT
In the event of a dispute and failing an amicable agreement, the Commercial Court of Paris shall have exclusive jurisdiction.`,
        lastUpdated: '2024-10-24' 
    },
    { 
        id: 'privacy', 
        title: 'Politique de Confidentialité', 
        title_en: 'Privacy Policy', 
        content: `1. RESPONSABLE DU TRAITEMENT
Le responsable du traitement des données est : Maxence FOULON, contact@maxence.design.

2. DONNÉES COLLECTÉES
Je limite la collecte des données personnelles au strict nécessaire (minimisation des données) :
- Formulaire de contact : Nom, Email, Entreprise, Message.
- Analytics : Données de navigation anonymisées.

3. FINALITÉS
- Gestion de la relation client (devis, facturation, support).
- Amélioration de l'expérience utilisateur sur le site.

4. PARTAGE DES DONNÉES
Vos données ne sont jamais vendues. Elles peuvent être accessibles par mes sous-traitants techniques stricts (Hébergement : Netlify, Paiement : Stripe éventuel) uniquement pour les besoins du service.

5. VOS DROITS
Conformément à la loi "Informatique et Libertés" et au RGPD, vous pouvez exercer vos droits d'accès, rectification, effacement de vos données en me contactant par email.

6. COOKIES
Ce site utilise des cookies purement techniques et des traceurs de mesure d'audience exemptés de consentement (ou avec votre accord préalable selon la configuration).`, 
        content_en: `1. DATA CONTROLLER
The data controller is: Maxence FOULON, contact@maxence.design.

2. COLLECTED DATA
I limit the collection of personal data to what is strictly necessary (data minimization):
- Contact form: Name, Email, Company, Message.
- Analytics: Anonymized navigation data.

3. PURPOSES
- Customer relationship management (quotes, billing, support).
- Improvement of user experience on the site.

4. DATA SHARING
Your data is never sold. It may be accessible by my strict technical subcontractors (Hosting: Netlify, Payment: Stripe possible) only for service needs.

5. YOUR RIGHTS
In accordance with GDPR laws, you can exercise your rights of access, rectification, deletion of your data by contacting me by email.

6. COOKIES
This site uses purely technical cookies and audience measurement trackers exempt from consent (or with your prior agreement depending on configuration).`,
        lastUpdated: '2024-10-24' 
    },
];

const AppContent: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [counter, setCounter] = useState(0);
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  
  // Admin State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminView, setAdminView] = useState<AdminView>('overview');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  // Data State
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [services, setServices] = useState<ServicePack[]>(INITIAL_SERVICES);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS);
  const [quotes, setQuotes] = useState<Quote[]>(INITIAL_QUOTES);
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS);
  const [legalDocs, setLegalDocs] = useState<LegalDoc[]>(INITIAL_LEGAL);

  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [selectedCaseStudyId, setSelectedCaseStudyId] = useState<number | null>(null);
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);

  // --- EFFECTS ---
  useEffect(() => {
    window.scrollTo(0, 0);
    if (currentPage !== 'portfolio') setSelectedProjectId(null);
    if (currentPage !== 'casestudies') setSelectedCaseStudyId(null);
    if (currentPage !== 'legal') setSelectedDocId(null);
  }, [currentPage]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounter((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setLoading(false), 800);
          return 100;
        }
        const increment = prev < 80 ? Math.floor(Math.random() * 5) + 2 : 1;
        return Math.min(prev + increment, 100);
      });
    }, 30);
    return () => clearInterval(interval);
  }, []);

  // --- UTILS ---
  const addNotification = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
      const id = Math.random().toString(36).substring(7);
      setNotifications(prev => [...prev, { id, message, type }]);
      setTimeout(() => {
          setNotifications(prev => prev.filter(n => n.id !== id));
      }, 3000);
  };

  const exportToCSV = (data: any[], filename: string) => {
      if (!data || !data.length) {
          addNotification("No data to export", "error");
          return;
      }
      const headers = Object.keys(data[0]);
      const csvContent = [
          headers.join(','),
          ...data.map(row => headers.map(fieldName => JSON.stringify(row[fieldName])).join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `${filename}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      addNotification(`${filename} exported successfully`, "success");
  };

  // --- DATA HANDLERS ---

  const handleAddClient = (newClient: Omit<Client, 'id' | 'joinDate' | 'totalRevenue'>) => {
    const client: Client = {
      ...newClient,
      id: Math.floor(Math.random() * 10000),
      joinDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
      totalRevenue: '€0'
    };
    setClients(prev => [client, ...prev]);
    addNotification(`Client ${client.name} added successfully`);
  };

  const handleUpdateClient = (id: number, updatedData: Partial<Client>) => {
      setClients(prev => prev.map(c => c.id === id ? { ...c, ...updatedData } : c));
      addNotification("Client updated successfully");
  };

  const handleDeleteClient = (id: number) => {
      setClients(prev => prev.filter(c => c.id !== id));
      // Cascade delete
      setQuotes(prev => prev.filter(q => q.clientId !== id));
      setInvoices(prev => prev.filter(i => i.clientId !== id));
      setAppointments(prev => prev.filter(a => a.clientId !== id));
      addNotification("Client deleted");
  };

  const handleConvertLead = (id: number) => {
    setClients(prev => prev.map(c => c.id === id ? { ...c, status: 'active' } : c));
    addNotification("Lead converted to Client");
  };

  const handleAddQuote = (newQuote: Omit<Quote, 'id' | 'status' | 'date'>) => {
    const quote: Quote = {
      ...newQuote,
      id: `Q-2024-${Math.floor(Math.random() * 1000)}`,
      status: 'draft',
      date: new Date().toISOString().split('T')[0]
    };
    setQuotes(prev => [quote, ...prev]);
    addNotification("Quote created successfully");
  };

  const handleDeleteQuote = (id: string) => {
      setQuotes(prev => prev.filter(q => q.id !== id));
      addNotification("Quote deleted");
  };

  const handleUpdateQuoteStatus = (id: string, status: Quote['status']) => {
    setQuotes(prev => prev.map(q => q.id === id ? { ...q, status } : q));
    addNotification(`Quote marked as ${status}`);
  };

  const handleConvertToInvoice = (quote: Quote) => {
    const newInvoice: Invoice = {
        id: `INV-${Math.floor(Math.random() * 10000)}`,
        quoteId: quote.id,
        clientId: quote.clientId,
        clientName: quote.clientName,
        amount: quote.amount,
        status: 'pending',
        date: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    };
    setInvoices(prev => [newInvoice, ...prev]);
    handleUpdateQuoteStatus(quote.id, 'accepted');
    addNotification("Invoice generated from Quote");
    setAdminView('finance'); // Redirect to view invoice
  };

  const handleDeleteInvoice = (id: string) => {
      setInvoices(prev => prev.filter(i => i.id !== id));
      addNotification("Invoice deleted");
  };

  const handleUpdateInvoiceStatus = (id: string, status: Invoice['status']) => {
    setInvoices(prev => prev.map(i => i.id === id ? { ...i, status } : i));
    
    if (status === 'paid') {
       const inv = invoices.find(i => i.id === id);
       if(inv) {
         setClients(prev => prev.map(c => {
            if (c.id === inv.clientId) {
                const currentRev = parseInt(c.totalRevenue.replace(/[^0-9]/g, '')) || 0;
                return { ...c, totalRevenue: `€${(currentRev + inv.amount).toLocaleString()}` };
            }
            return c;
         }));
         addNotification(`Payment recorded. Revenue updated.`, "success");
       }
    } else {
        addNotification(`Invoice marked as ${status}`);
    }
  };

  const handleAddAppointment = (newApt: Omit<Appointment, 'id'>) => {
      setAppointments(prev => [...prev, { ...newApt, id: Math.random() }]);
      addNotification("Appointment scheduled");
  };

  const handleDeleteAppointment = (id: number) => {
      setAppointments(prev => prev.filter(a => a.id !== id));
      addNotification("Appointment cancelled", "info");
  };

  const handleAdminLogin = () => {
      setIsAuthenticated(true);
      addNotification("Welcome back, Admin");
  };
  
  const handleLogout = () => { 
      setIsAuthenticated(false); 
      setCurrentPage('home');
      addNotification("Logged out successfully");
  };

  // ADMIN ROUTE
  if (currentPage === 'admin') {
      if (!isAuthenticated) {
          return <AdminLogin onLogin={handleAdminLogin} />;
      }
      return (
          <AdminLayout currentView={adminView} onChangeView={setAdminView} onLogout={handleLogout}>
              {adminView === 'overview' && (
                <DashboardOverview 
                    clients={clients} 
                    quotes={quotes} 
                    invoices={invoices} 
                    onAddClient={handleAddClient}
                    onUpdateClient={handleUpdateClient}
                    onDeleteClient={handleDeleteClient}
                    onExport={exportToCSV}
                />
              )}
              {adminView === 'crm' && (
                <CRMManager 
                    clients={clients} 
                    onAddClient={handleAddClient} 
                    onUpdateClient={handleUpdateClient}
                    onDeleteClient={handleDeleteClient}
                    onConvertLead={handleConvertLead} 
                />
              )}
              {adminView === 'finance' && (
                <FinanceManager 
                    quotes={quotes} 
                    invoices={invoices} 
                    clients={clients} 
                    onAddQuote={handleAddQuote}
                    onUpdateQuoteStatus={handleUpdateQuoteStatus}
                    onDeleteQuote={handleDeleteQuote}
                    onConvertToInvoice={handleConvertToInvoice}
                    onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
                    onDeleteInvoice={handleDeleteInvoice}
                    onDownload={fileName => addNotification(`Downloading ${fileName}...`)}
                />
              )}
              {adminView === 'calendar' && (
                <CalendarManager 
                    appointments={appointments} 
                    clients={clients}
                    onAddAppointment={handleAddAppointment}
                    onDeleteAppointment={handleDeleteAppointment}
                />
              )}
              {adminView === 'legal' && (
                <LegalManager 
                   legalDocs={legalDocs} 
                   setLegalDocs={setLegalDocs}
                />
              )}
              
              {adminView === 'projects' && <ProjectManager title="Portfolio" projects={projects} setProjects={setProjects} />}
              {adminView === 'casestudies' && <ProjectManager title="Case Studies" projects={projects} setProjects={setProjects} />}
              {adminView === 'services' && <ServiceManager services={services} setServices={setServices} />}
              {adminView === 'messages' && <MessageInbox messages={messages} setMessages={setMessages} />}
              
              {/* Global Notifications */}
              <div className="fixed bottom-6 right-6 z-[100] flex flex-col gap-3 pointer-events-none">
                  {notifications.map(n => (
                      <div key={n.id} className={`px-4 py-3 rounded shadow-2xl flex items-center gap-3 animate-in slide-in-from-right-12 fade-in duration-300 ${
                          n.type === 'error' ? 'bg-red-500 text-white' : 'bg-white text-black'
                      }`}>
                          <div className={`w-2 h-2 rounded-full ${n.type === 'error' ? 'bg-white' : 'bg-green-500'}`}></div>
                          <span className="text-xs font-bold uppercase tracking-wide">{n.message}</span>
                          <button onClick={() => setNotifications(prev => prev.filter(item => item.id !== n.id))} className="ml-2 pointer-events-auto"><X size={14}/></button>
                      </div>
                  ))}
              </div>
          </AdminLayout>
      );
  }

  // PUBLIC ROUTES
  const renderPublicPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onChangePage={setCurrentPage} />;
      case 'services':
        return <ServicesPage services={services} />;
      case 'portfolio':
        if (selectedProjectId !== null) {
          return <PortfolioDetailPage id={selectedProjectId} onBack={() => setSelectedProjectId(null)} />;
        }
        return <PortfolioPage items={projects} onProjectClick={(id) => { setSelectedProjectId(id); window.scrollTo(0,0); }} />;
      case 'casestudies':
        if (selectedCaseStudyId !== null) {
            return <CaseStudyDetailPage id={selectedCaseStudyId} onBack={() => setSelectedCaseStudyId(null)} />;
        }
        return <CaseStudiesPage projects={projects} onProjectClick={(id) => { setSelectedCaseStudyId(id); window.scrollTo(0,0); }} />;
      case 'legal':
        if (selectedDocId) {
            const doc = legalDocs.find(d => d.id === selectedDocId);
            if (doc) return <LegalPage doc={doc} />;
        }
        // Default fallback if no specific doc selected or list view (if needed)
        return <LegalPage doc={legalDocs[0]} />;
      case 'contact':
        return <Contact />;
      default:
        return <Home onChangePage={setCurrentPage} />;
    }
  };

  return (
    <div className="relative min-h-screen bg-background text-white font-sans selection:bg-primary selection:text-black">
      
      {/* CINEMATIC PRELOADER */}
      <div 
        className={`fixed inset-0 z-[100] bg-[#050505] flex items-end justify-end pb-12 pr-12 transition-transform duration-1000 ease-[cubic-bezier(0.76,0,0.24,1)] ${
          loading ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <div className="text-[15vw] font-display font-bold leading-none text-white tracking-tighter tabular-nums">
            {counter}%
        </div>
      </div>

      <CustomCursor />
      
      <div className="bg-noise"></div>

      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar currentPage={currentPage} onNavigate={setCurrentPage} />
        
        <main className="flex-grow">
          {renderPublicPage()}
        </main>
        
        <Footer onNavigate={(page, id) => { 
            setCurrentPage(page); 
            if(id && page === 'legal') setSelectedDocId(id); 
        }} />
      </div>
    </div>
  );
};

const App: React.FC = () => {
    return (
        <LanguageProvider>
            <AppContent />
        </LanguageProvider>
    );
}

export default App;
