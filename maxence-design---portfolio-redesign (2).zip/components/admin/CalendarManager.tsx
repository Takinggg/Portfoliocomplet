import React, { useState, useMemo } from 'react';
import { Appointment, Client } from '../../types';
import { Clock, Video, MapPin, Plus, X, Save, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';

interface CalendarManagerProps {
  appointments: Appointment[];
  clients: Client[];
  onAddAppointment: (apt: any) => void;
  onDeleteAppointment?: (id: number) => void;
}

export const CalendarManager: React.FC<CalendarManagerProps> = ({ appointments, clients, onAddAppointment, onDeleteAppointment }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newApt, setNewApt] = useState({ clientId: '', title: '', date: '', time: '', duration: '60', type: 'discovery' });
  
  // Week Navigation State
  // For demo purposes, we start with a base date of Monday Oct 21, 2024 to match initial data
  const [currentWeekStart, setCurrentWeekStart] = useState(new Date('2024-10-21'));

  const weekDates = useMemo(() => {
      const dates = [];
      for(let i=0; i<5; i++) {
          const d = new Date(currentWeekStart);
          d.setDate(currentWeekStart.getDate() + i);
          dates.push(d);
      }
      return dates;
  }, [currentWeekStart]);

  const changeWeek = (delta: number) => {
      const newDate = new Date(currentWeekStart);
      newDate.setDate(currentWeekStart.getDate() + (delta * 7));
      setCurrentWeekStart(newDate);
  };

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  const hours = [9, 10, 11, 12, 13, 14, 15, 16, 17, 18];

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      const client = clients.find(c => c.id === parseInt(newApt.clientId));
      if (client && newApt.date && newApt.time) {
          onAddAppointment({
              clientId: client.id,
              clientName: client.name,
              title: newApt.title,
              date: `${newApt.date}T${newApt.time}:00`, 
              duration: parseInt(newApt.duration),
              type: newApt.type
          });
          setIsModalOpen(false);
          setNewApt({ clientId: '', title: '', date: '', time: '', duration: '60', type: 'discovery' });
      }
  };

  const handleDelete = (id: number, e: React.MouseEvent) => {
      e.stopPropagation();
      if (onDeleteAppointment && confirm('Cancel this appointment?')) {
          onDeleteAppointment(id);
      }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-display font-bold text-white">Calendar</h1>
            <p className="text-neutral-400">Manage appointments and deliveries.</p>
          </div>
          <div className="flex items-center gap-4">
              <div className="flex items-center bg-black border border-white/10 rounded-lg p-1">
                  <button onClick={() => changeWeek(-1)} className="p-2 hover:bg-white/10 rounded text-white"><ChevronLeft size={16} /></button>
                  <span className="px-4 text-sm font-mono text-neutral-400">
                      {currentWeekStart.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} - 
                      {new Date(currentWeekStart.getTime() + 4*24*60*60*1000).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                  </span>
                  <button onClick={() => changeWeek(1)} className="p-2 hover:bg-white/10 rounded text-white"><ChevronRight size={16} /></button>
              </div>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 bg-[#111] border border-white/10 rounded-lg text-sm text-white hover:bg-white/5"
              >
                  <Plus size={16} /> Book Meeting
              </button>
          </div>
      </div>

      <div className="bg-[#0F0F0F] border border-white/5 rounded-xl overflow-x-auto">
          <div className="min-w-[800px]">
              {/* Header */}
              <div className="grid grid-cols-6 border-b border-white/5">
                  <div className="p-4 text-center text-xs font-mono text-neutral-500 uppercase border-r border-white/5">Time</div>
                  {weekDates.map((d, i) => (
                      <div key={i} className="p-4 text-center border-r border-white/5 last:border-0">
                          <div className="text-xs font-bold text-white uppercase">{d.toLocaleDateString('en-US', { weekday: 'short' })}</div>
                          <div className="text-xs text-neutral-500 font-mono">{d.getDate()}</div>
                      </div>
                  ))}
              </div>

              {/* Grid */}
              <div className="relative">
                  {hours.map(hour => (
                      <div key={hour} className="grid grid-cols-6 border-b border-white/5 h-24">
                          <div className="p-2 text-center text-xs font-mono text-neutral-600 border-r border-white/5">
                              {hour}:00
                          </div>
                          {[0,1,2,3,4].map(dayIndex => (
                              <div key={dayIndex} className="relative border-r border-white/5 last:border-0 group hover:bg-white/[0.02]">
                                  {/* Render Appointments */}
                                  {appointments.filter(apt => {
                                      const aptDate = new Date(apt.date);
                                      const dayDate = weekDates[dayIndex];
                                      return aptDate.getDate() === dayDate.getDate() && 
                                             aptDate.getMonth() === dayDate.getMonth() &&
                                             aptDate.getHours() === hour;
                                  }).map(apt => (
                                      <div 
                                        key={apt.id}
                                        onClick={(e) => handleDelete(apt.id, e)}
                                        className={`absolute inset-x-1 top-1 rounded p-2 text-xs border cursor-pointer hover:brightness-110 transition-all z-10 ${
                                            apt.type === 'discovery' ? 'bg-blue-500/10 border-blue-500/20 text-blue-300' :
                                            apt.type === 'review' ? 'bg-purple-500/10 border-purple-500/20 text-purple-300' :
                                            'bg-green-500/10 border-green-500/20 text-green-300'
                                        }`}
                                        style={{ height: `${(apt.duration / 60) * 100 - 5}%` }}
                                      >
                                          <div className="font-bold truncate">{apt.clientName}</div>
                                          <div className="truncate opacity-70">{apt.title}</div>
                                      </div>
                                  ))}
                              </div>
                          ))}
                      </div>
                  ))}
              </div>
          </div>
      </div>

      {/* BOOKING MODAL */}
      {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
              <div className="bg-[#111] border border-white/10 rounded-2xl p-8 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-300">
                  <div className="flex justify-between items-center mb-6">
                      <h2 className="text-xl font-bold text-white">Book Appointment</h2>
                      <button onClick={() => setIsModalOpen(false)} className="text-neutral-500 hover:text-white"><X size={20}/></button>
                  </div>
                  <form onSubmit={handleSubmit} className="space-y-4">
                       <select
                        className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none text-sm" 
                        value={newApt.clientId} onChange={e => setNewApt({...newApt, clientId: e.target.value})} required
                      >
                          <option value="">Select Client</option>
                          {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                      <input 
                        placeholder="Meeting Title" 
                        className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none text-sm" 
                        value={newApt.title} onChange={e => setNewApt({...newApt, title: e.target.value})} required 
                      />
                      <div className="grid grid-cols-2 gap-4">
                          <input 
                            type="date"
                            className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none text-sm" 
                            value={newApt.date} onChange={e => setNewApt({...newApt, date: e.target.value})} required 
                          />
                          <input 
                            type="time"
                            className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none text-sm" 
                            value={newApt.time} onChange={e => setNewApt({...newApt, time: e.target.value})} required 
                          />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <select
                            className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none text-sm" 
                            value={newApt.type} onChange={e => setNewApt({...newApt, type: e.target.value})}
                          >
                              <option value="discovery">Discovery</option>
                              <option value="review">Review</option>
                              <option value="delivery">Delivery</option>
                          </select>
                          <select
                            className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none text-sm" 
                            value={newApt.duration} onChange={e => setNewApt({...newApt, duration: e.target.value})}
                          >
                              <option value="30">30 min</option>
                              <option value="60">1 hour</option>
                              <option value="90">1.5 hours</option>
                              <option value="120">2 hours</option>
                          </select>
                      </div>

                      <button type="submit" className="w-full py-3 bg-primary text-black font-bold rounded hover:bg-white transition-colors flex items-center justify-center gap-2 mt-4">
                          <Save size={18} /> Schedule Meeting
                      </button>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};