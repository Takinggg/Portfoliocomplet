import React, { useState, useEffect } from 'react';
import { Project, KPI, TechItem } from '../../types';
import { Plus, Edit2, Trash2, X, Save, Image as ImageIcon, Layers, BarChart2, FileText, Globe, ChevronRight } from 'lucide-react';

interface ProjectManagerProps {
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  title?: string;
}

type Tab = 'general' | 'story' | 'tech';
type Lang = 'fr' | 'en';

export const ProjectManager: React.FC<ProjectManagerProps> = ({ projects, setProjects, title = "Projects" }) => {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('general');
  const [lang, setLang] = useState<Lang>('fr');
  
  // Empty state for new project
  const [formData, setFormData] = useState<Partial<Project>>({
    title: '', title_en: '',
    client: '',
    category: 'SaaS',
    description: '', description_en: '',
    challenge: '', challenge_en: '',
    solution: '', solution_en: '',
    image: '',
    tags: [],
    link: '#',
    stats: [],
    techStack: []
  });

  // Temporary state for list inputs
  const [tempTag, setTempTag] = useState('');
  const [tempStat, setTempStat] = useState<KPI>({ label: '', value: '', change: '' });
  const [tempTech, setTempTech] = useState<TechItem>({ name: '', category: '' });

  const handleEdit = (project: Project) => {
    setEditingId(project.id);
    setFormData(JSON.parse(JSON.stringify(project))); // Deep copy
    setIsAdding(false);
    setActiveTab('general');
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this project?')) {
      setProjects(prev => prev.filter(p => p.id !== id));
    }
  };

  const handleSave = () => {
    if (editingId) {
      setProjects(prev => prev.map(p => p.id === editingId ? { ...p, ...formData } as Project : p));
    } else {
      const newId = Math.max(...projects.map(p => p.id), 0) + 1;
      const newProject = { ...formData, id: newId } as Project;
      setProjects(prev => [...prev, newProject]);
    }
    closeForm();
  };

  const closeForm = () => {
    setEditingId(null);
    setIsAdding(false);
    setFormData({
      title: '', title_en: '',
      client: '',
      category: 'SaaS',
      description: '', description_en: '',
      image: '',
      tags: [],
      link: '#',
      stats: [],
      techStack: []
    });
  };

  // Helpers for lists
  const addTag = () => { if(tempTag) { setFormData({...formData, tags: [...(formData.tags||[]), tempTag]}); setTempTag(''); }};
  const addStat = () => { if(tempStat.label && tempStat.value) { setFormData({...formData, stats: [...(formData.stats||[]), tempStat]}); setTempStat({label:'', value:'', change:''}); }};
  const addTech = () => { if(tempTech.name) { setFormData({...formData, techStack: [...(formData.techStack||[]), tempTech]}); setTempTech({name:'', category:''}); }};

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <div>
            <h1 className="text-3xl font-display font-bold text-white mb-2">{title}</h1>
            <p className="text-neutral-400">Manage your portfolio content and translations.</p>
        </div>
        <button 
            onClick={() => { closeForm(); setIsAdding(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-lg font-bold text-sm hover:bg-primary transition-colors"
        >
            <Plus size={18} /> Add Project
        </button>
      </div>

      {/* FORM OVERLAY */}
      {(isAdding || editingId) && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 md:p-6">
            <div className="bg-[#111] border border-white/10 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
                
                {/* HEADER */}
                <div className="flex justify-between items-center p-6 border-b border-white/10 bg-[#151515]">
                    <div className="flex items-center gap-4">
                        <h2 className="text-xl font-bold text-white">{editingId ? 'Edit Project' : 'New Project'}</h2>
                        <div className="h-6 w-[1px] bg-white/10"></div>
                        {/* Language Switcher */}
                        <div className="flex bg-black rounded-lg p-1 border border-white/10">
                            <button onClick={() => setLang('fr')} className={`px-3 py-1 rounded text-xs font-bold uppercase transition-colors ${lang === 'fr' ? 'bg-white text-black' : 'text-neutral-500 hover:text-white'}`}>FR</button>
                            <button onClick={() => setLang('en')} className={`px-3 py-1 rounded text-xs font-bold uppercase transition-colors ${lang === 'en' ? 'bg-white text-black' : 'text-neutral-500 hover:text-white'}`}>EN</button>
                        </div>
                    </div>
                    <button onClick={closeForm} className="text-neutral-500 hover:text-white"><X size={24} /></button>
                </div>

                {/* TABS */}
                <div className="flex border-b border-white/10 bg-[#0F0F0F]">
                    <button onClick={() => setActiveTab('general')} className={`flex-1 py-4 text-sm font-bold uppercase tracking-widest flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'general' ? 'border-primary text-white' : 'border-transparent text-neutral-500 hover:text-white'}`}>
                        <Layers size={16} /> General
                    </button>
                    <button onClick={() => setActiveTab('story')} className={`flex-1 py-4 text-sm font-bold uppercase tracking-widest flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'story' ? 'border-primary text-white' : 'border-transparent text-neutral-500 hover:text-white'}`}>
                        <FileText size={16} /> Story ({lang})
                    </button>
                    <button onClick={() => setActiveTab('tech')} className={`flex-1 py-4 text-sm font-bold uppercase tracking-widest flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'tech' ? 'border-primary text-white' : 'border-transparent text-neutral-500 hover:text-white'}`}>
                        <BarChart2 size={16} /> Data & Tech
                    </button>
                </div>
                
                {/* CONTENT SCROLLABLE */}
                <div className="flex-1 overflow-y-auto p-8 bg-[#0A0A0A]">
                    
                    {/* --- GENERAL TAB --- */}
                    {activeTab === 'general' && (
                        <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="field-label">Title ({lang})</label>
                                    <input 
                                        type="text" 
                                        value={lang === 'fr' ? formData.title : formData.title_en} 
                                        onChange={e => lang === 'fr' ? setFormData({...formData, title: e.target.value}) : setFormData({...formData, title_en: e.target.value})}
                                        className="input-field"
                                        placeholder="Project Name"
                                    />
                                </div>
                                <div>
                                    <label className="field-label">Client</label>
                                    <input 
                                        type="text" 
                                        value={formData.client} 
                                        onChange={e => setFormData({...formData, client: e.target.value})}
                                        className="input-field"
                                    />
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="field-label">Category</label>
                                    <select 
                                        value={formData.category} 
                                        onChange={e => setFormData({...formData, category: e.target.value})}
                                        className="input-field"
                                    >
                                        <option>SaaS</option>
                                        <option>Fintech</option>
                                        <option>E-Commerce</option>
                                        <option>Mobile App</option>
                                        <option>Web3</option>
                                        <option>Design System</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="field-label">Live Link</label>
                                    <input type="text" value={formData.link} onChange={e => setFormData({...formData, link: e.target.value})} className="input-field" />
                                </div>
                            </div>
                            <div>
                                <label className="field-label">Main Image</label>
                                <div className="flex gap-2">
                                    <input type="text" value={formData.image} onChange={e => setFormData({...formData, image: e.target.value})} className="input-field flex-1" placeholder="https://..." />
                                    <div className="w-12 h-12 bg-white/5 rounded border border-white/10 flex items-center justify-center shrink-0 overflow-hidden">
                                        {formData.image ? <img src={formData.image} className="w-full h-full object-cover" /> : <ImageIcon size={20} className="text-neutral-600"/>}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* --- STORY TAB --- */}
                    {activeTab === 'story' && (
                        <div className="space-y-6">
                            <div>
                                <label className="field-label">Short Description ({lang})</label>
                                <textarea 
                                    rows={2}
                                    value={lang === 'fr' ? formData.description : formData.description_en} 
                                    onChange={e => lang === 'fr' ? setFormData({...formData, description: e.target.value}) : setFormData({...formData, description_en: e.target.value})}
                                    className="input-field"
                                    placeholder="Brief summary for portfolio cards..."
                                ></textarea>
                            </div>
                            <div>
                                <label className="field-label">The Challenge ({lang})</label>
                                <textarea 
                                    rows={4}
                                    value={lang === 'fr' ? formData.challenge : formData.challenge_en} 
                                    onChange={e => lang === 'fr' ? setFormData({...formData, challenge: e.target.value}) : setFormData({...formData, challenge_en: e.target.value})}
                                    className="input-field"
                                    placeholder="What was the problem?"
                                ></textarea>
                            </div>
                            <div>
                                <label className="field-label">The Solution ({lang})</label>
                                <textarea 
                                    rows={4}
                                    value={lang === 'fr' ? formData.solution : formData.solution_en} 
                                    onChange={e => lang === 'fr' ? setFormData({...formData, solution: e.target.value}) : setFormData({...formData, solution_en: e.target.value})}
                                    className="input-field"
                                    placeholder="How did you solve it?"
                                ></textarea>
                            </div>
                        </div>
                    )}

                    {/* --- TECH TAB --- */}
                    {activeTab === 'tech' && (
                        <div className="space-y-8">
                            {/* TAGS */}
                            <div>
                                <label className="field-label">Simple Tags</label>
                                <div className="flex gap-2 mb-2">
                                    <input type="text" value={tempTag} onChange={e => setTempTag(e.target.value)} className="input-field" placeholder="Ex: React Native" />
                                    <button onClick={addTag} className="px-4 bg-white/10 hover:bg-white hover:text-black rounded text-white transition-colors"><Plus size={18}/></button>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {formData.tags?.map((t, i) => (
                                        <span key={i} className="px-2 py-1 bg-white/5 border border-white/10 rounded text-xs flex items-center gap-2">
                                            {t} <button onClick={() => setFormData({...formData, tags: formData.tags?.filter((_, idx) => idx !== i)})}><X size={12}/></button>
                                        </span>
                                    ))}
                                </div>
                            </div>

                            {/* STATS */}
                            <div>
                                <label className="field-label">Key Metrics (KPIs)</label>
                                <div className="grid grid-cols-3 gap-2 mb-2">
                                    <input type="text" value={tempStat.value} onChange={e => setTempStat({...tempStat, value: e.target.value})} className="input-field" placeholder="Value (ex: +50%)" />
                                    <input type="text" value={tempStat.label} onChange={e => setTempStat({...tempStat, label: e.target.value})} className="input-field" placeholder="Label (ex: Users)" />
                                    <button onClick={addStat} className="px-4 bg-white/10 hover:bg-white hover:text-black rounded text-white transition-colors"><Plus size={18}/></button>
                                </div>
                                <div className="space-y-2">
                                    {formData.stats?.map((s, i) => (
                                        <div key={i} className="flex items-center justify-between p-2 bg-white/5 border border-white/10 rounded">
                                            <span className="text-sm font-bold text-white">{s.value} <span className="font-normal text-neutral-400">{s.label}</span></span>
                                            <button onClick={() => setFormData({...formData, stats: formData.stats?.filter((_, idx) => idx !== i)})} className="text-red-500"><Trash2 size={14}/></button>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* TECH STACK */}
                             <div>
                                <label className="field-label">Tech Stack</label>
                                <div className="grid grid-cols-3 gap-2 mb-2">
                                    <input type="text" value={tempTech.name} onChange={e => setTempTech({...tempTech, name: e.target.value})} className="input-field" placeholder="Name (ex: Next.js)" />
                                    <input type="text" value={tempTech.category} onChange={e => setTempTech({...tempTech, category: e.target.value})} className="input-field" placeholder="Category (ex: Framework)" />
                                    <button onClick={addTech} className="px-4 bg-white/10 hover:bg-white hover:text-black rounded text-white transition-colors"><Plus size={18}/></button>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {formData.techStack?.map((t, i) => (
                                        <span key={i} className="px-2 py-1 bg-white/5 border border-white/10 rounded text-xs flex items-center gap-2">
                                            {t.name} <span className="text-neutral-600">({t.category})</span>
                                            <button onClick={() => setFormData({...formData, techStack: formData.techStack?.filter((_, idx) => idx !== i)})}><X size={12}/></button>
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                </div>

                {/* FOOTER */}
                <div className="p-6 border-t border-white/10 bg-[#151515]">
                    <button 
                        onClick={handleSave}
                        className="w-full bg-primary text-black font-bold py-3 rounded hover:bg-white transition-colors flex items-center justify-center gap-2"
                    >
                        <Save size={18} /> Save Project
                    </button>
                </div>

            </div>
        </div>
      )}

      {/* LIST */}
      <div className="grid grid-cols-1 gap-4">
        {projects.map(project => (
            <div key={project.id} className="bg-[#0F0F0F] border border-white/5 p-4 rounded-xl flex items-center justify-between group hover:border-white/20 transition-colors">
                <div className="flex items-center gap-4">
                    <div className="w-16 h-12 rounded bg-neutral-800 overflow-hidden">
                        <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
                    </div>
                    <div>
                        <div className="flex items-center gap-2">
                            <h3 className="text-white font-bold">{project.title}</h3>
                            {project.title_en && <span className="text-[10px] bg-white/10 px-1 rounded text-neutral-400">EN</span>}
                        </div>
                        <p className="text-xs text-neutral-500">{project.client} • {project.category}</p>
                    </div>
                </div>
                
                <div className="flex items-center gap-2">
                    <button onClick={() => handleEdit(project)} className="p-2 hover:bg-white/10 rounded text-neutral-400 hover:text-white transition-colors">
                        <Edit2 size={18} />
                    </button>
                    <button onClick={() => handleDelete(project.id)} className="p-2 hover:bg-red-500/10 rounded text-neutral-400 hover:text-red-500 transition-colors">
                        <Trash2 size={18} />
                    </button>
                </div>
            </div>
        ))}
      </div>

      <style>{`
        .field-label {
            display: block;
            font-size: 0.75rem;
            font-family: monospace;
            color: #737373;
            text-transform: uppercase;
            margin-bottom: 0.5rem;
        }
        .input-field {
            width: 100%;
            background-color: black;
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 0.25rem;
            padding: 0.75rem;
            color: white;
            outline: none;
            transition: border-color 0.2s;
        }
        .input-field:focus {
            border-color: #CCFF00;
        }
      `}</style>
    </div>
  );
};