import React, { useState } from 'react';
import { LegalDoc } from '../../types';
import { Save, X, Globe, Plus, Edit2, Trash2 } from 'lucide-react';

interface LegalManagerProps {
  legalDocs: LegalDoc[];
  setLegalDocs: React.Dispatch<React.SetStateAction<LegalDoc[]>>;
}

type Lang = 'fr' | 'en';

export const LegalManager: React.FC<LegalManagerProps> = ({ legalDocs, setLegalDocs }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [lang, setLang] = useState<Lang>('fr');
  const [isAdding, setIsAdding] = useState(false);
  
  const [formData, setFormData] = useState<Partial<LegalDoc>>({
      id: '', title: '', title_en: '', content: '', content_en: ''
  });

  const handleEdit = (doc: LegalDoc) => {
      setEditingId(doc.id);
      setFormData(doc);
      setIsAdding(true);
  };

  const handleSave = () => {
      if (editingId) {
          setLegalDocs(prev => prev.map(doc => doc.id === editingId ? { ...doc, ...formData, lastUpdated: new Date().toISOString().split('T')[0] } as LegalDoc : doc));
      } else {
          const newDoc = { 
              ...formData, 
              id: formData.id || `doc-${Date.now()}`,
              lastUpdated: new Date().toISOString().split('T')[0] 
          } as LegalDoc;
          setLegalDocs(prev => [...prev, newDoc]);
      }
      setIsAdding(false);
      setEditingId(null);
      setFormData({ id: '', title: '', title_en: '', content: '', content_en: '' });
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <div>
            <h1 className="text-3xl font-display font-bold text-white mb-2">Legal & Compliance</h1>
            <p className="text-neutral-400">Manage terms, conditions, and policies.</p>
        </div>
        <button 
            onClick={() => { setIsAdding(true); setEditingId(null); setFormData({id: '', title: '', title_en: '', content: '', content_en: ''}); }}
            className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-lg font-bold text-sm hover:bg-primary transition-colors"
        >
            <Plus size={18} /> Add Document
        </button>
      </div>

      {isAdding ? (
          <div className="bg-[#0F0F0F] border border-white/10 rounded-xl p-8 shadow-2xl animate-in zoom-in-95 duration-200">
              <div className="flex justify-between items-center mb-6 border-b border-white/10 pb-4">
                  <h2 className="text-xl font-bold text-white">{editingId ? 'Edit Document' : 'New Document'}</h2>
                   <div className="flex bg-black rounded-lg p-1 border border-white/10">
                        <button onClick={() => setLang('fr')} className={`px-3 py-1 rounded text-xs font-bold uppercase transition-colors ${lang === 'fr' ? 'bg-white text-black' : 'text-neutral-500 hover:text-white'}`}>FR</button>
                        <button onClick={() => setLang('en')} className={`px-3 py-1 rounded text-xs font-bold uppercase transition-colors ${lang === 'en' ? 'bg-white text-black' : 'text-neutral-500 hover:text-white'}`}>EN</button>
                    </div>
              </div>

              <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                      <div>
                          <label className="text-xs font-mono text-neutral-500 uppercase mb-2 block">Document Title ({lang})</label>
                          <input 
                            type="text"
                            value={lang === 'fr' ? formData.title : formData.title_en}
                            onChange={e => lang === 'fr' ? setFormData({...formData, title: e.target.value}) : setFormData({...formData, title_en: e.target.value})}
                            className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none"
                          />
                      </div>
                      {!editingId && (
                           <div>
                              <label className="text-xs font-mono text-neutral-500 uppercase mb-2 block">Slug / ID</label>
                              <input 
                                type="text"
                                value={formData.id}
                                onChange={e => setFormData({...formData, id: e.target.value})}
                                className="w-full bg-black border border-white/20 rounded p-3 text-white focus:border-primary outline-none"
                                placeholder="e.g. terms-of-use"
                              />
                          </div>
                      )}
                  </div>

                  <div>
                       <label className="text-xs font-mono text-neutral-500 uppercase mb-2 block">Content ({lang})</label>
                       <textarea 
                            rows={15}
                            value={lang === 'fr' ? formData.content : formData.content_en}
                            onChange={e => lang === 'fr' ? setFormData({...formData, content: e.target.value}) : setFormData({...formData, content_en: e.target.value})}
                            className="w-full bg-black border border-white/20 rounded p-4 text-white focus:border-primary outline-none font-mono text-sm leading-relaxed"
                            placeholder="# Title..."
                       />
                       <p className="text-xs text-neutral-600 mt-2">Supports simple text. Use line breaks for paragraphs.</p>
                  </div>

                  <div className="flex justify-end gap-4">
                      <button onClick={() => setIsAdding(false)} className="px-6 py-3 rounded-lg border border-white/10 text-white hover:bg-white/5">Cancel</button>
                      <button onClick={handleSave} className="px-6 py-3 rounded-lg bg-primary text-black font-bold hover:bg-white transition-colors">Save Document</button>
                  </div>
              </div>
          </div>
      ) : (
          <div className="grid grid-cols-1 gap-4">
              {legalDocs.map(doc => (
                  <div key={doc.id} className="bg-[#0F0F0F] border border-white/5 p-6 rounded-xl flex items-center justify-between group hover:border-white/20 transition-colors">
                      <div>
                          <h3 className="text-xl font-bold text-white mb-1">{doc.title}</h3>
                          <div className="text-xs text-neutral-500 font-mono">Last updated: {doc.lastUpdated}</div>
                      </div>
                      <div className="flex gap-2">
                           <button onClick={() => handleEdit(doc)} className="p-2 rounded hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"><Edit2 size={18} /></button>
                           <button onClick={() => setLegalDocs(prev => prev.filter(d => d.id !== doc.id))} className="p-2 rounded hover:bg-red-500/10 text-neutral-400 hover:text-red-500 transition-colors"><Trash2 size={18} /></button>
                      </div>
                  </div>
              ))}
              {legalDocs.length === 0 && (
                  <div className="text-center py-12 text-neutral-500 border border-dashed border-white/10 rounded-xl">
                      No legal documents created yet.
                  </div>
              )}
          </div>
      )}
    </div>
  );
};