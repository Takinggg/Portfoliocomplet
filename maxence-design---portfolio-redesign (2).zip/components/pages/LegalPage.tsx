import React from 'react';
import { LegalDoc } from '../../types';
import { useLanguage } from '../../src/context/LanguageContext';
import { Reveal } from '../Reveal';

interface LegalPageProps {
  doc: LegalDoc;
}

export const LegalPage: React.FC<LegalPageProps> = ({ doc }) => {
  const { resolve, t } = useLanguage();
  
  return (
    <div className="pt-32 pb-20 bg-background min-h-screen animate-in fade-in duration-700">
      <div className="container mx-auto px-6 max-w-4xl">
        <Reveal>
             <h1 className="font-display font-bold text-5xl md:text-7xl text-white mb-8">{resolve(doc, 'title')}<span className="text-primary">.</span></h1>
             <div className="text-sm font-mono text-neutral-500 mb-16 pb-8 border-b border-white/10">
                 {t('legal.last_updated')} {doc.lastUpdated}
             </div>
        </Reveal>
        
        <Reveal delay={100}>
            <div className="prose prose-invert prose-lg max-w-none">
                {/* Simple rendering of text content with line breaks */}
                {resolve(doc, 'content').split('\n').map((paragraph, idx) => (
                    <p key={idx} className="text-neutral-300 font-light leading-relaxed mb-6">
                        {paragraph}
                    </p>
                ))}
            </div>
        </Reveal>
      </div>
    </div>
  );
};